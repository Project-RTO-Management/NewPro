package com.app.entities;

public enum PaymentMode {
ONLINE, OFFLINE
}
