package com.app.entities;

public enum examType {
DRIVING, THEORY
}
