package com.app.entities;

public enum Gender {
MALE,FEMALE,TRANSGENDER,PREFER_NOT_TO_SAY
}
