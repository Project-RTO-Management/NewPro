package com.app.entities;

public enum PaymentType {
FEES, FINE
}
