package com.app.entities;

public enum Answer {
A,B,C,D
}
