package com.app.dto;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;

import org.hibernate.validator.constraints.Length;

import com.app.entities.Category;
import com.app.entities.User;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public class ProductDTO {
	@JsonProperty(access = Access.READ_ONLY)
	private Long prodId;
	@NotNull
	@Min(value=5, message = "name should be greater than 5 character")
	private String productName;
	private String description;
	@NotNull
	private int productQuantity;
	@NotNull
	private Category category;
	@NotNull
	private double price;
	@NotNull
	private int availStock;
	@Past(message= "Earlier date required")
	private LocalDate productionDate;
	@JsonProperty(access = Access.WRITE_ONLY)
	private Long userId;
}
