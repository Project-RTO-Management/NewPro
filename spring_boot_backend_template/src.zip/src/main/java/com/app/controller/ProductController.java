package com.app.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.app.dto.ProductDTO;
import com.app.entities.Category;
import com.app.entities.Product;
import com.app.service.ProductService;

@RestController
@RequestMapping("/products")
@CrossOrigin(value = "http://localhost:3000")
@Validated
public class ProductController {
@Autowired
private ProductService prodService;

public ProductController() {
	System.out.println("inside prod controller");
}

@GetMapping
public ResponseEntity<?> getAllProducts(){
	System.out.println("inside get all prod");
	return ResponseEntity.status(HttpStatus.OK).body(prodService.getAllproductDetails());
}

@PostMapping
public ProductDTO addNewProduct(@RequestBody @Valid ProductDTO transientProduct) {
	System.out.println("in add new product");
	return prodService.addProduct(transientProduct);
}

@GetMapping("/{prodId}")
public ProductDTO getProductByProviderId(@PathVariable @NotNull(message="ID should not be null") Long provId) {
	System.out.println("in get product by id");
	return prodService.getProdById(provId);
}

@GetMapping("/Category/{cat}")
public ResponseEntity<?> getProductByCategory(@PathVariable  @NotNull(message="Category should not be null") Category cat){
	System.out.println("in get product by category");
	return ResponseEntity.ok( prodService.getProdByCat(cat));
}

@PutMapping("/{detachedProduct}")
public ProductDTO updateProduct(@RequestBody @Valid ProductDTO detachedProduct) {
	System.out.println("in update product");
	return prodService.updateProd(detachedProduct);
}

@DeleteMapping("/{prodId}")
public String deleteProduct(@PathVariable @NotNull(message = "Id not be null") Long prodId) {
	System.out.println("in delete product");
	return prodService.deleteProd(prodId);
}
}


//- Fetch all products
//
//- Add new Product
//
//- Update product details (product company, product description, price and inStock can be updated)
//
//- Fetch all products by type
//
//- Delete provider
//
//- Fetch all products of given provider , by provider id