package com.app.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.OneToOne;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.*;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString

public class User extends BaseEntity{
	@Column(length = 20, unique = true)
	private String userName;
	@Column(length=30)
	private String email;
	@Column(length=30)
	private String password;
	@Column(length = 20)
	private String phoneNo;
	@Enumerated(EnumType.STRING)
	@Column()
	private Role role;
	@Column()
	private LocalDate regDate;
	@OneToOne
	private Product prod;
}




//User has the following attributes:user_id(Integer),user_name(String),
//email(String),phoneno(String),password(String),role(Enum-PROVIDER,CUSTOMER),regDate(Date)
