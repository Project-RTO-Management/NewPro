package com.app.entities;

public enum Category {
	Animals, Electronic_toys, Doll, Educational_toys, Construction_toys 
}

