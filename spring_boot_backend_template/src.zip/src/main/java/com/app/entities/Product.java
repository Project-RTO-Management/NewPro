package com.app.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="product")
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Product extends BaseEntity{
@Column(length = 20, unique = true)
private String productName;
@Column(length=30)
private String description;
@Column()
private int productQuantity;
@Enumerated(EnumType.STRING)
@Column()
private Category category;
@Column()
private double price;
@Column()
private int availStock;
@Column()
private LocalDate productionDate;

@OneToOne
private User user;


}


//
//Product has the following attributes: product_id(Integer),product_name(String),description(String)
//,product_quantity(int),price(double),category(Enum),provider_id(int)FK,inStock(boolean),production_date(Date)
//