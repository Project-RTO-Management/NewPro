package com.app.service;

import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.validation.Valid;

import org.apache.catalina.mapper.Mapper;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.custom_exceptions.ResourceNotFoundException;
import com.app.dao.UserDao;
import com.app.dao.productDao;
import com.app.dto.ProductDTO;
import com.app.entities.Category;
import com.app.entities.Product;
import com.app.entities.User;
@Service
@Transactional
public class ProductServiceImpl implements ProductService{
@Autowired
private productDao prodDao;
@Autowired
private UserDao userDao;
@Autowired
private ModelMapper mapper;

	@Override
	public List<ProductDTO> getAllproductDetails() {
		List<Product> list= prodDao.findAll();
		List<ProductDTO> list1 = list.stream().map(e->mapper.map(e, ProductDTO.class)).collect(Collectors.toList());
		return list1;
	}


	@Override
	public ProductDTO getProdById(Long provId) {
		Product prod = prodDao.findAllByUserId(provId);
		
		 return mapper.map(prod, ProductDTO.class);
	}

	@Override
	public List<ProductDTO> getProdByCat(Category cat) {
		List<Product> list= prodDao.findAllByCategory(cat);
		return list.stream().map(e->mapper.map(e, ProductDTO.class)).collect(Collectors.toList());
	}

	@Override
	public ProductDTO updateProd(ProductDTO detachedProduct) {
		Product prod = mapper.map(detachedProduct, Product.class);
		if(prodDao.existsById(prod.getId())) {
		return mapper.map(prodDao.save(prod), ProductDTO.class);
		}
		throw new ResourceNotFoundException("product not found");
	}

	@Override
	public String deleteProd(Long prodId) {
		if(prodDao.existsById(prodId)) {
		prodDao.deleteById(prodId);
		return "Product Deleted";
		}
		return "product not found";
	}

	@Override
	public ProductDTO addProduct(@Valid ProductDTO transientProduct) {
	Product prod = mapper.map(transientProduct, Product.class);
	prodDao.save(prod);
		return  mapper.map(prod, ProductDTO.class);
	}


	@Override
	public ProductDTO updateProd(Product detachedProduct) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
