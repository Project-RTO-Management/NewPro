package com.app.service;

import java.util.List;

import javax.validation.Valid;

import com.app.dto.ProductDTO;
import com.app.entities.Category;
import com.app.entities.Product;

public interface ProductService {

	List<ProductDTO> getAllproductDetails();

	ProductDTO getProdById(Long prodId);

	List<ProductDTO> getProdByCat(Category cat);

	ProductDTO updateProd(Product detachedProduct);

	String deleteProd(Long prodId);

	ProductDTO addProduct(@Valid ProductDTO transientProduct);

	ProductDTO updateProd(ProductDTO detachedProduct);


}
