package com.app.entities;

public enum Role {
	APPLICANT, ADMIN, TRAFFICPOLICE
}
